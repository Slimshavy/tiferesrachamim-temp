﻿var timeFormDate = function (date) {

    var hour = date.getHours();
    var minute = date.getMinutes();
    var ampm = 'am';

    if (hour > 12) {
        ampm = 'pm';
        hour = hour - 12;
    }
    else if (hour == 12) {
        ampm = 'pm';
    }
    else if (hour == 0) {
        hour = 12;
    }

    return '' + hour + ':' + minute + ' ' + ampm;
}


$(document).ready(function () {
    $.get("http://www.hebcal.com/shabbat/?cfg=json&zip=11213&m=50&a=on", function (data) {

        var candleLighting = timeFormDate(new Date(data.items[0].date));
        var shabbosEnd = timeFormDate(new Date(data.items[2].date));
        var parsha = data.items[1].title;

        $("#zmanim-header").text("Zmanim for Shabbos " + parsha);
        $(".candle-lighting").text(candleLighting);
        $(".shul-maariv").text("5:00 pm");
        $(".shul-shachris").text("10:30 am");
        //$(".shabbos-shkiah").text("N/A");
        $(".shabbos-ends").text(shabbosEnd);  
    });
    
});

